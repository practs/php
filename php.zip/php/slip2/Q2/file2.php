<?php

$dir = $_GET['dir'];
$ext = $_GET['ext'];

$dir_p = opendir($dir);

echo "<h1>List of Files ::</h1>";
	while(($file = readdir($dir_p)) != null) 
	{
		$needle = ".".$ext;
		if(strstr($file,$needle))
		echo "<h2>".$file."</h2>";
	}

?>

<?php

$filename = $_GET['file'];
$optn = $_GET['m'];

if($optn == 'display')

{
$type = filetype($filename);
if($type != null)
echo "<h2>Type of File : </h2>".$type."<br>";
else
echo "<h2>File does not exist</h2>";
}
else
if($optn == 'delete')
{
echo "<h2>File is ";
if(unlink($filename))
echo "Deleted</h2>";
else
echo "Not Deleted</h2>";
}
?>

<?php
$url = 'https://www.google.com';

print_r(parse_url($url));
print_r(parse_url($url, PHP_URL_SCHEME));
print_r(parse_url($url, PHP_URL_HOST));
echo "path".(parse_url($url, PHP_URL_PATH));

?>

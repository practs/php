<?php
function add($n1,$n2=10)
{
	return($n1+$n2);
}
function sub($n2,$n1=3)
{
	return($n1-$n2);
}
function mul($n1,$n2=5)
{
	return($n1*$n2);
}
function div($n1,$n2=3)
{
	return($n1/$n2);
}
?>
